# Licenses
This is a review of all source files and associated licenses used. Information about the KORUZA Pro system is collected manually and with the https://github.com/daald/dpkg-licenses tool.

Please note that this is work in progress and may not be complete nor correct. Prior to using the KORUZA Pro source you should check the licensing yourself.

## Files:
 * koruza-license-review.ods Table of repositories and licenses
 * dpkg-licenses.txt collection of licensing information from the main Raspberry Pi system
