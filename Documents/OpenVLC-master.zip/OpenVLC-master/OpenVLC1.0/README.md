=== This is the driver for both the OpenVLC1.0 and OpenVLC1.1 capes === Link to the official version of the driver is: https://github.com/openvlc/openvlc ===

Please follow the instructions on http://www.openvlc.org/openvlc.html for the preparation & test.

If you have any questions, you can send us emails or post the questions here: https://groups.google.com/forum/#!forum/openvlc
